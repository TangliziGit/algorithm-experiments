package org.tanglizi.algo

object App extends App {
  println( "Hello World!" )
}
