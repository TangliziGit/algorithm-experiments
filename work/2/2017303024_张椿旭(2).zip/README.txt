利用scala编写, 以配好`pom.xml`, 可以直接下载依赖运行测试程序.
或者利用构建好的jar包, 进行测试

1、实现批作业调度代码，并完成测试；（排列树问题）
见 BatchJobSchedulingTest
输入
    n = 3, cost = [[2, 1], [3, 1], [2, 3]]
输出
    cost = 18, scheduling = [0, 1, 2]

2、实现一个有趣的高精度数代码，并完成测试（子集树问题）
见 InterestingBigNumberTest
无输入
输出
    3608528850368400786036725

3、实现课后作业5-18实现世界名画陈列馆问题（不重复监视）
见 ExhibitionHallTest
输入
    width = 4, height = 4
输出
    cost 4
    0, 0, 1, 0
    1, 0, 0, 0
    0, 0, 0, 1
    0, 1, 0, 0
